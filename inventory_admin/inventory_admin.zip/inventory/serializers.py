from rest_framework import serializers
from .models import OnHandBalanceReport

class OnHandBalanceReportSerializer(serializers.ModelSerializer):
    quantity = serializers.IntegerField()
    allocated = serializers.IntegerField()
    available = serializers.IntegerField()
    bin = serializers.IntegerField()
    level = serializers.IntegerField()
    price = serializers.FloatField()
    value = serializers.FloatField()

    class Meta:
        model = OnHandBalanceReport
        fields = '__all__'
        
        

from .models import ProjectedObsolescence

class ProjectedObsolescenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectedObsolescence
        fields = '__all__'